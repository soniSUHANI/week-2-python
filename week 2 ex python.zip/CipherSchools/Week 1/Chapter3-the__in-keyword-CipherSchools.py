name = "Sushant"
#  in keyword
#  if with in 
if  "h" in "Sushant":
    print("h is present in the name")
else:
    print("not present")