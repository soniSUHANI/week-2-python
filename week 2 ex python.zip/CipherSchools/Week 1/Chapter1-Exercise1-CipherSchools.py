# Exercise Based on escape sequences 

print("this \\\\ double backslash")
print("these are /\\/\\/\\/\\ mountains")
print("he is \tawesome")
print(" \\\" \\n")

# \" = "
#  \\= \
# \\\"=\"