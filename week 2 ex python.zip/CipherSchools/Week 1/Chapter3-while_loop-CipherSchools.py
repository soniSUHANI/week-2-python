#  loop
#  while loop, for loop
print("hello world") # 10 times
i = 1
while i<=10:
    print(f"sushant {i}")
    i = i  + 1
