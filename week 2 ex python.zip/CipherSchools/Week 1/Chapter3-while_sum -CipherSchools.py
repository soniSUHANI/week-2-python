# Sum of Numbers Program using while loop in Python

total = 0
i = 1
while i <= 10:
    total += i
    i += 1
print(total)
   