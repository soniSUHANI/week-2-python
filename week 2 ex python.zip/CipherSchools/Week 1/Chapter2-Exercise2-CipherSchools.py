# WAP to calculate the average of the given input User
# a = input("Enter the first number: ")
# b = input("Enter the first Second: ")
# c = input("Enter the first Third: ")

a,b,c = input("Enter the three numbers seperated with commas: ").split(",")

print(f"Average of three numbers: {(int(a) + int(b) + int(c)) / 3}")



