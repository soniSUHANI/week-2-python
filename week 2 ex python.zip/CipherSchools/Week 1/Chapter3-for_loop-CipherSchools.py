#  for loop with range function 
for i in range (1,11):
    print(f"hello world : {i}")
    print("this is line \n")