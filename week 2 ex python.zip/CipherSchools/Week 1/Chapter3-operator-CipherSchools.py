# Check two condition at smae time
# and , or

name = 'abc'
age = 19
if name == 'abdc' or age  == 17:
    print("True")
else:
    print("False")
