# WAP to print the reverse of the username input
a = input("Enter you name: ")
print(a[-1::-1])