#  check emepty or not 
#  important
name = input("Enter you name: ")
if name:  # true of string is not empty
    print(f"your name is {name}")
else:
    print("empty")