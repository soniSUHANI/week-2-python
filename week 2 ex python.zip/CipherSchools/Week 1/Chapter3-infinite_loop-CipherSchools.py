# infinite loop
i = 0
while i <= 10:
    print("hello world")