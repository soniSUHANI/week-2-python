# name ="Sushant"
# for i in range(len(name)):
#     print(name[i])

# name = "Sushant"
# for i in name:
#     print(i)

# 1256 find sum of this digits

# num = input("Enter a number: ")
# total = 0
# for i in num:
#     total += int(i)
# print(total)

# while loop
# i=0
# while i<10:
#     print(i)
#     i+=1

# for loop
# for i in range(1,11):
#     print(i)


# break keyword
# for i in range(1,11):
#     if i==5:
#         break
#     print(i)

# for i in range(1,11):
#     if i ==5:
#         continue
#     print(i)

for i in "Sushant":
    print(i)
