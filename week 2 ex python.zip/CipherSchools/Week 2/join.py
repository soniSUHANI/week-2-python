# join method
# covert list to string

user_info = ['Sushant', '17']
print(','.join(user_info))