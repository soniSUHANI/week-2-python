# immutable
# faster than list
# days = ('monday', 'tuesday')
# methods 
# count, index 
# len function
# slicing
example = ('one','two','three')
print(example[:2])
