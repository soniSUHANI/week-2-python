fruits = ['orange', 'apple', 'pear', 'banana', 'kiwi']
# pop method
fruits.pop(1) #by default last element with argument at specific index

# del method at specific index[1]
# remove method 
fruits.remove('banana')

print(fruits)