def add_three(x,y,z):
    return x+y+z
print(add_three(5,5,5))