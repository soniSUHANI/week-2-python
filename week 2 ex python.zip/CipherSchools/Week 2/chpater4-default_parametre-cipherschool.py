def user_info(first_name = 'unknown', last_name = 'unknown', age = None):
    print(f"Your first name is : {first_name}")
    print(f"Your last name is : {last_name}")
    print(f"Your age is : {age}")

user_info("Sushant",17)

# only last one can be defaluit