fruits = ['orange', 'apple', 'pear', 'banana', 'kiwi']

# for loop
# for fruits in fruits:
#     print(fruits)

# while lpp

i=0
while i < len(fruits):
    print(fruits[i])
    i+=1