numbers = [1,2,3,4]
print(numbers)

mixed = [1,2,"word"]
print(mixed[-1])

mixed[1] = 'two'
print(mixed)


# how to add data in list

# fruits = ['grapes', 'apple']
# fruits.append('mango')
# print(fruits)



fruits1 =['mango', 'apple']
# fruits1.insert(1,"grapes")
# print(fruits1)
fruits2 =['orange']
# ectend item extension
fruits1.extend(fruits2)
print(fruits1)


# extend list ke nadr list
