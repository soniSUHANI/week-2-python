numbers = [6,60,2]
# print(min(numbers))
# print(max(numbers))

def greatest(l):
    return max(l) - min(l)
print(greatest(numbers))