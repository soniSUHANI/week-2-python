# for i in range (0,11,2): #1st start 2nd stop 3rd step argument
#     print(i)

for i in range(-1,-11,-1):
    print(i)