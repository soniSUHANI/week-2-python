# split method
# convert string to list

# name,age = 'Sushant,17'.split(',')
name, age = input("Enter you name and age comma seperated: ").split(',')
print(name)
print(age)