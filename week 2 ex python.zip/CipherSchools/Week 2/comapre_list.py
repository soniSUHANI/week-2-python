fruits1 = ['orange', 'apple','peras']
fruits2 = ['banana','kiwi','apple','banna']
fruits3 = ['banana','kiwi','apple', 'banna']

print(fruits2 == fruits3)
print(fruits1 is fruits3)

