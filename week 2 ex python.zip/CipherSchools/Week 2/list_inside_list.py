matrix = [[1,2,3],[4,5,6],[7,8,9]] #2d list
# 3 item three list
# print(matrix[0])

# for sublist in matrix:
#     for i in sublist:
#         print(i)


print(matrix[1][1])
print(type(matrix))