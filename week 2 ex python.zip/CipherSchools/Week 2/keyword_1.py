fruits = ['orange', 'apple', 'pear', 'banana', 'kiwi']
if 'apple' in fruits:
    print('present')
else:
    print('not present')