# # function
# name ="Sushant"
# print(len(name))

# def add(x,y):
#     return x+y
# a = int(input("Enter first number: "))
# b = int(input("Enter second number: "))
# total = add(a,b)
# print(total)


def add(x,y):
    return x+y
first = input("Enter your name: ")
title = input("Enter your title: ")
Full_name = add(first,title)
print(Full_name)