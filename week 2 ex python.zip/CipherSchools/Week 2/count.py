fruits = ['orange', 'apple', 'pear', 'banana', 'kiwi']
# print(fruits.count('orange'))

# fruits.sort()
# print(fruits)

